/**
 * Gutenberg Blocks
 *
 * All blocks should be included here since this is the file that
 * Webpack is compiling as the input file.
 */

import './google-fonts/index.js';
