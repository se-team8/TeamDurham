<?php
/**
 * @var string $tabUrl Fully qualified URL of the tab.
 * @var array $tweaks
 */

?>
<div id="ame-tweak-manager">
	<?php require AME_ROOT_DIR . '/modules/actor-selector/actor-selector-template.php'; ?>

	<pre><?php print_r($tweaks); ?></pre>
</div>

