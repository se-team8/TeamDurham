<?php
namespace Bookly\Frontend\Modules\Booking\Proxy;

use Bookly\Lib;

/**
 * Class Cart
 * @package Bookly\Frontend\Modules\Booking\Proxy
 *
 * @method static void renderCustomField( \stdClass $custom_field, array $cf_item ) Render file browser control on step details.
 */
abstract class Files extends Lib\Base\Proxy
{

}