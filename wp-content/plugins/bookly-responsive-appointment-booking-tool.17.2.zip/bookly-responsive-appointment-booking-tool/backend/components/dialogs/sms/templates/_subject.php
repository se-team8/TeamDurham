<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<input type="hidden" name="notification[subject]" value=""/>
<input type="hidden" name="notification[gateway]" value="sms"/>
