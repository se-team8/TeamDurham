<?php
namespace Bookly\Backend\Components\TinyMce\Proxy;

use Bookly\Lib;

/**
 * Class SpecialDays
 * @package Bookly\Backend\Components\TinyMce\Proxy\Proxy
 *
 * @method static void renderStaffCabinetSettings() Render settings in Staff Cabinet shortcode.
 */
abstract class SpecialDays extends Lib\Base\Proxy
{

}