<?php
namespace Bookly\Backend\Components\TinyMce\Proxy;

use Bookly\Lib;

/**
 * Class SpecialHours
 * @package Bookly\Backend\Components\TinyMce\Proxy\Proxy
 *
 * @method static void renderStaffCabinetSettings() Render settings in Staff Cabinet shortcode.
 */
abstract class SpecialHours extends Lib\Base\Proxy
{

}