<?php
namespace Bookly\Backend\Modules\Dashboard\Proxy;

use Bookly\Lib;

/**
 * Class Pro
 * @package Bookly\Backend\Modules\Dashboard\Proxy
 *
 * @method static void renderAnalytics() Render analytics section.
 */
abstract class Pro extends Lib\Base\Proxy
{

}