<?php
namespace Bookly\Backend\Modules\Appearance\Proxy;

use Bookly\Lib;

/**
 * Class WaitingList
 * @package Bookly\Backend\Modules\Appearance\Proxy
 *
 * @method static void renderInfoText() Render WL info text in Time step.
 */
abstract class WaitingList extends Lib\Base\Proxy
{

}