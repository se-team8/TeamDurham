<?php
namespace Bookly\Backend\Modules\Notifications\Proxy;

use Bookly\Lib;

/**
 * @since Bookly 16.5
 * @deprecated To be removed in the future.
 */
abstract class Pro extends Lib\Base\Proxy
{
}