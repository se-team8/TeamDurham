<?php
namespace Bookly\Backend\Modules\Staff\Proxy;

use Bookly\Lib;

/**
 * Class Ratings
 * @package Bookly\Backend\Modules\Staff\Proxy
 *
 * @method static void renderStaffServiceRating( int $staff_id, int $service_id, string $type ) Render rating.
 */
abstract class Ratings extends Lib\Base\Proxy
{

}